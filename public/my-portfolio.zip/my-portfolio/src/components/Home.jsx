import { useState } from "react";
import StatCard from "./StatCard";

// Props: owner (object), onNavigate (function)
export default function Home({ owner, onNavigate }) {
  // STATE: a greeting that changes when the visitor clicks the button
  const [showIntro, setShowIntro] = useState(false);

  // Dashboard numbers. Edit these to match your real info.
  const stats = [
    { value: "[Number]", label: "[e.g. Projects completed]" },
    { value: "[Number]", label: "[e.g. Technologies learned]" },
    { value: "[Number]", label: "[e.g. Years of study]" },
  ];

  return (
    <section className="page">
      <p className="page__kicker">Welcome</p>
      <h1 className="hero-title">
        Hi, I'm {owner.fullName}.<br />
        {/* [One-line statement about what you do, e.g. "I build simple, useful websites."] */}
        [One-line statement about what you do]
      </h1>

      <p className="lead-text">
        {/* [Short 2-3 sentence introduction about yourself] */}
        [Short 2-3 sentence introduction about yourself]
      </p>

      <div className="button-row">
        {/* EVENT HANDLING: navigate to another page */}
        <button className="btn-solid" onClick={() => onNavigate("Projects")}>
          View my projects
        </button>
        <button className="btn-outline" onClick={() => setShowIntro(!showIntro)}>
          {showIntro ? "Hide fun fact" : "Show a fun fact"}
        </button>
      </div>

      {showIntro && (
        <p className="callout">
          {/* [A fun fact or personal motto about you] */}
          [A fun fact or personal motto about you]
        </p>
      )}

      <div className="row g-3 mt-4">
        {stats.map((s, i) => (
          <div className="col-12 col-md-4" key={i}>
            {/* PROPS: sending value and label into StatCard */}
            <StatCard value={s.value} label={s.label} />
          </div>
        ))}
      </div>
    </section>
  );
}
