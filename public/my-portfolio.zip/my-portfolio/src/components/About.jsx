import { useState } from "react";

// Props: owner (object)
export default function About({ owner }) {
  // STATE: which tab is open
  const [tab, setTab] = useState("Education");

  const skills = ["[Skill 1]", "[Skill 2]", "[Skill 3]", "[Skill 4]", "[Skill 5]"];

  // Each tab has a list of entries. Add or remove entries as needed.
  const timeline = {
    Education: [
      {
        heading: "[Degree / Course]",
        place: "[School Name]",
        years: "[Start year - End year]",
      },
    ],
    Experience: [
      {
        heading: "[Role / Activity]",
        place: "[Company or Organization]",
        years: "[Start year - End year]",
      },
    ],
  };

  return (
    <section className="page">
      <p className="page__kicker">About</p>
      <h2 className="page__title">About {owner.fullName}</h2>

      <p className="lead-text">
        {/* [Write 3-5 sentences about your background, interests, and goals] */}
        [Write 3-5 sentences about your background, interests, and goals]
      </p>

      <h3 className="section-label">Skills</h3>
      <div className="tag-row">
        {skills.map((s) => (
          <span className="tag tag--big" key={s}>{s}</span>
        ))}
      </div>

      <h3 className="section-label">Background</h3>
      <div className="button-row">
        {Object.keys(timeline).map((name) => (
          <button
            key={name}
            className={`chip ${tab === name ? "is-active" : ""}`}
            onClick={() => setTab(name)}
          >
            {name}
          </button>
        ))}
      </div>

      <ul className="timeline">
        {timeline[tab].map((item, i) => (
          <li key={i}>
            <p className="timeline__heading">{item.heading}</p>
            <p className="timeline__meta">{item.place} · {item.years}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
